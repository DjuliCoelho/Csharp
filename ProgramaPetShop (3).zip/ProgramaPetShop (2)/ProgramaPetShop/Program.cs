﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        var baseUrl = "http://localhost:5038"; //url da API
        var httpClient = new HttpClient();

        while (true)
        {
            Console.WriteLine("Escolha uma entidade para gerenciar:");
            Console.WriteLine("1 - Funcionário");
            Console.WriteLine("2 - Cliente");
            Console.WriteLine("3 - Produto");
            Console.WriteLine("4 - Estoque");
            Console.WriteLine("5 - Sair");

            var escolhaEntidade = Console.ReadLine();

            switch (escolhaEntidade)
            {
                case "1":
                    await GerenciarFuncionario(httpClient, baseUrl + "/funcionarios");
                    break;

                case "2":
                    await GerenciarCliente(httpClient, baseUrl + "/clientes");
                    break;

                case "3":
                    await GerenciarProduto(httpClient, baseUrl + "/produtos");
                    break;

                case "4":
                    await GerenciarEstoque(httpClient, baseUrl + "/estoques");
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }

    #region ENTIDADES

    class Funcionario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Cargo { get; set; }
    }

    class Cliente
    {
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Fone { get; set; }
    }

    class Produto
    {
        public string Nome { get; set; }
        public string Codigo { get; set; }
        public string Valor { get; set; }
    }

    class Estoque
    {
        public int Id  { get; set; }
        public string Nome { get; set; }
        public string Quantidade { get; set; }
    }

    #endregion

    #region MÉTODOS
    static async Task GerenciarFuncionario(HttpClient httpClient, string apiUrl)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Funcionário:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoFuncionario = LerDadosFuncionario();
                    await PostFuncionario(httpClient, apiUrl, novoFuncionario);
                    break;

                case "2":
                    await ListarFuncionarios(httpClient, apiUrl);
                    break;

                case "3":
                    Console.WriteLine("Digite o ID do Funcionário a ser atualizado:");
                    if (int.TryParse(Console.ReadLine(), out int idAtualizar)) // Converte a entrada do usuário para int
                    
                    {
                    var funcionarioAtualizado = LerDadosFuncionario();
                    await PutFuncionario(httpClient, $"{apiUrl}/{idAtualizar}", funcionarioAtualizado);
                    
                    }
                    else
                    {
                    Console.WriteLine("ID inválido. Tente novamente.");    
                    }
                    break;

                case "4":
                    Console.WriteLine("Digite o ID do Funcionário a ser deletado:");
                    var idDeletar = Console.ReadLine();
                    await Delete(httpClient, $"{apiUrl}/{idDeletar}");
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }




    static async Task GerenciarCliente(HttpClient httpClient, string apiUrl)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Cliente:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoCliente = LerDadosCliente();
                    await PostCliente(httpClient, apiUrl, novoCliente);
                    break;

                case "2":
                    await ListarClientes(httpClient, apiUrl);
                    break;

                case "3":
                    Console.WriteLine("Digite o CPF do Cliente a ser atualizado:");
                    var cpfAtualizar = Console.ReadLine();
                    var clienteAtualizado = LerDadosCliente();
                    await PutCliente(httpClient, $"{apiUrl}/{cpfAtualizar}", clienteAtualizado);
                    break;

                case "4":
                    Console.WriteLine("Digite o CPF do Cliente a ser deletado:");
                    var cpfDeletar = Console.ReadLine();
                    await Delete(httpClient, $"{apiUrl}/{cpfDeletar}");
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }
    




    static async Task GerenciarProduto(HttpClient httpClient, string apiUrl)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Produto:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoProduto = LerDadosProduto();
                    await PostProduto(httpClient, apiUrl, novoProduto);
                    break;

                case "2":
                    await ListarProdutos(httpClient, apiUrl);
                    break;

                case "3":
                    Console.WriteLine("Digite o CÓDIGO do Produto a ser atualizado:");
                    var codigoAtualizar = Console.ReadLine();
                    var produtoAtualizado = LerDadosProduto();
                    await PutProduto(httpClient, $"{apiUrl}/{codigoAtualizar}", produtoAtualizado);
                    break;

                case "4":
                    Console.WriteLine("Digite o CÓDIGO do Produto a ser deletado:");
                    var codigoDeletar = Console.ReadLine();
                    await Delete(httpClient, $"{apiUrl}/{codigoDeletar}");
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }




    static async Task GerenciarEstoque(HttpClient httpClient, string apiUrl)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Estoque:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoEstoque = LerDadosEstoque();
                    await PostEstoque(httpClient, apiUrl, novoEstoque);
                    break;

                case "2":
                    await ListarEstoques(httpClient, apiUrl);
                    break;

                case "3":
                    Console.WriteLine("Digite o ID do Estoque a ser atualizado:");
                    if (int.TryParse(Console.ReadLine(), out int idAtualizar)) // Converte a entrada do usuário para int
                    
                    {
                    var estoqueAtualizado = LerDadosEstoque();
                    await PutEstoque(httpClient, $"{apiUrl}/{idAtualizar}", estoqueAtualizado);
                    
                    }
                    else
                    {
                    Console.WriteLine("ID inválido. Tente novamente.");    
                    }
                    break;


                case "4":
                    Console.WriteLine("Digite o ID do Estoque a ser deletado:");
                    var idDeletar = Console.ReadLine();
                    await Delete(httpClient, $"{apiUrl}/{idDeletar}");
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }
    
    
    
    static Funcionario LerDadosFuncionario()
    {
        Console.WriteLine("Por favor, preencha os campos do Funcionário:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Cargo: ");
        var cargo = Console.ReadLine();

        var novoFuncionario = new Funcionario
        {
            Nome = nome,
            Cargo = cargo
        };

        return novoFuncionario;
    }




    static Cliente LerDadosCliente()
    {
        Console.WriteLine("Por favor, preencha os campos do Cliente:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Cpf: ");
        var cpf = Console.ReadLine();

        Console.Write("Fone: ");
        var fone = Console.ReadLine();

        var novoCliente = new Cliente
        {
            Nome = nome,
            Cpf = cpf,
            Fone = fone
        };

        return novoCliente;
    }





    static Produto LerDadosProduto()
    {
        Console.WriteLine("Por favor, preencha os campos do Produto:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Codigo: ");
        var codigo = Console.ReadLine();

        Console.Write("Valor: ");
        var valor = Console.ReadLine();

        var novoProduto = new Produto
        {
            Nome = nome,
            Codigo = codigo,
            Valor = valor
        };

        return novoProduto;
    }





    static Estoque LerDadosEstoque()
    {
        Console.WriteLine("Por favor, preencha os campos do Estoque:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Quantidade: ");
        var Quantidade = Console.ReadLine();

        var novoEstoque = new Estoque
        {
            Nome = nome,
            Quantidade = Quantidade
        };

        return novoEstoque;
    }


    #region CADASTRO
    static async Task PostFuncionario(HttpClient httpClient, string apiUrl, Funcionario novoFuncionario)
    {
        try
        {
            var response = await httpClient.PostAsJsonAsync(apiUrl, novoFuncionario);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Funcionário cadastrado com sucesso!");
            }
            else
            {
                Console.WriteLine($"Erro ao cadastrar funcionário. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }



    static async Task PostCliente(HttpClient httpClient, string apiUrl, Cliente novoCliente)
    {
        try
        {
            var response = await httpClient.PostAsJsonAsync(apiUrl, novoCliente);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Cliente cadastrado com sucesso!");
            }
            else
            {
                Console.WriteLine($"Erro ao cadastrar cliente. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }





    static async Task PostProduto(HttpClient httpClient, string apiUrl, Produto novoProduto)
    {
        try
        {
            var response = await httpClient.PostAsJsonAsync(apiUrl, novoProduto);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Produto cadastrado com sucesso!");
            }
            else
            {
                Console.WriteLine($"Erro ao cadastrar produto. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }





    static async Task PostEstoque(HttpClient httpClient, string apiUrl, Estoque novoEstoque)
    {
        try
        {
            var response = await httpClient.PostAsJsonAsync(apiUrl, novoEstoque);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Estoque cadastrado com sucesso!");
            }
            else
            {
                Console.WriteLine($"Erro ao cadastrar estoque. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }

    #endregion

    #region LISTAGEM
    static async Task ListarFuncionarios(HttpClient httpClient, string apiUrl)
    {
        try
        {
            var response = await httpClient.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();

                var funcionarios = JsonSerializer.Deserialize<Funcionario[]>(json);

                Console.WriteLine("Lista de Funcionários:");
                foreach (var funcionario in funcionarios)
                {
                    Console.WriteLine($"ID: {funcionario.Id}, Nome: {funcionario.Nome}, Cargo: {funcionario.Cargo}");
                }
            }
            else
            {
                Console.WriteLine($"Erro ao listar funcionários. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }





    static async Task ListarClientes(HttpClient httpClient, string apiUrl)
    {
        try
        {
            var response = await httpClient.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();

                var clientes = JsonSerializer.Deserialize<Cliente[]>(json);

                Console.WriteLine("Lista de Clientes:");
                foreach (var cliente in clientes)
                {
                    Console.WriteLine($"Nome: {cliente.Nome}, Cpf: {cliente.Cpf}, Fone: {cliente.Fone}");
                }
            }
            else
            {
                Console.WriteLine($"Erro ao listar cliente. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }





    static async Task ListarProdutos(HttpClient httpClient, string apiUrl)
    {
        try
        {
            var response = await httpClient.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();

                var produtos = JsonSerializer.Deserialize<Produto[]>(json);

                Console.WriteLine("Lista de Produtos:");
                foreach (var produto in produtos)
                {
                    Console.WriteLine($"Nome: {produto.Nome}, Codigo: {produto.Codigo}, Valor: {produto.Valor}");
                }
            }
            else
            {
                Console.WriteLine($"Erro ao listar produto. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }






    static async Task ListarEstoques(HttpClient httpClient, string apiUrl)
    {
        try
        {
            var response = await httpClient.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();

                var estoques = JsonSerializer.Deserialize<Estoque[]>(json);

                Console.WriteLine("Lista de Estoques:");
                foreach (var estoque in estoques)
                {
                    Console.WriteLine($"Id: {estoque.Id}, Nome: {estoque.Nome}, Quantia: {estoque.Quantidade}");
                }
            }
            else
            {
                Console.WriteLine($"Erro ao listar estoque. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }

    
    
    
    
    #endregion

    #region ATUALIZAÇÃO
    static async Task PutFuncionario(HttpClient httpClient, string apiUrl, Funcionario funcionarioAtualizado)
    {
        try
        {
            var jsonFuncionarioAtualizado = JsonSerializer.Serialize(funcionarioAtualizado);
            var content = new StringContent(jsonFuncionarioAtualizado, Encoding.UTF8, "application/json");

            var response = await httpClient.PutAsync(apiUrl, content);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Funcionário atualizado com sucesso!");
            }
            else
            {
                Console.WriteLine($"Erro ao atualizar funcionário. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }

    
    
    
    
    
    
    
    
    
    static async Task PutCliente(HttpClient httpClient, string apiUrl, Cliente clienteAtualizado)
{
    try
    {
        var jsonClienteAtualizado = JsonSerializer.Serialize(clienteAtualizado);
        var content = new StringContent(jsonClienteAtualizado, Encoding.UTF8, "application/json");

        HttpResponseMessage response; // Declare a variável aqui fora do switch

        switch (response = await httpClient.PutAsync(apiUrl, content)) // Atribua o resultado ao switch
        {
            case var success when response.IsSuccessStatusCode:
                Console.WriteLine("Cliente atualizado com sucesso!");
                break;

            default:
                Console.WriteLine($"Erro ao atualizar cliente. Código de status: {response.StatusCode}");
                break;
        }
    }
    catch (HttpRequestException e)
    {
        Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
    }
}








static async Task PutProduto(HttpClient httpClient, string apiUrl, Produto produtoAtualizado)
{
    try
    {
        var jsonProdutoAtualizado = JsonSerializer.Serialize(produtoAtualizado);
        var content = new StringContent(jsonProdutoAtualizado, Encoding.UTF8, "application/json");

        HttpResponseMessage response; // Declare a variável aqui fora do switch

        switch (response = await httpClient.PutAsync(apiUrl, content)) // Atribua o resultado ao switch
        {
            case var success when response.IsSuccessStatusCode:
                Console.WriteLine("Produto atualizado com sucesso!");
                break;

            default:
                Console.WriteLine($"Erro ao atualizar produto. Código de status: {response.StatusCode}");
                break;
        }
    }
    catch (HttpRequestException e)
    {
        Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
    }
}









static async Task PutEstoque(HttpClient httpClient, string apiUrl, Estoque estoqueAtualizado)
{
    try
    {
        var jsonEstoqueAtualizado = JsonSerializer.Serialize(estoqueAtualizado);
        var content = new StringContent(jsonEstoqueAtualizado, Encoding.UTF8, "application/json");

        HttpResponseMessage response; // Declare a variável aqui fora do switch

        switch (response = await httpClient.PutAsync(apiUrl, content)) // Atribua o resultado ao switch
        {
            case var success when response.IsSuccessStatusCode:
                Console.WriteLine("Estoque atualizado com sucesso!");
                break;

            default:
                Console.WriteLine($"Erro ao atualizar estoque. Código de status: {response.StatusCode}");
                break;
        }
    }
    catch (HttpRequestException e)
    {
        Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
    }
}




    







    
    
    
    #endregion

    #region EXCLUSÃO
    static async Task Delete(HttpClient httpClient, string apiUrl)
    {
        try
        {
            var response = await httpClient.DeleteAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Recurso excluído com sucesso!");
            }
            else
            {
                Console.WriteLine($"Erro ao excluir recurso. Código de status: {response.StatusCode}");
            }
        }
        catch (HttpRequestException e)
        {
            Console.WriteLine($"Erro na requisição HTTP: {e.Message}");
        }
    }

    
    #endregion

    #endregion
}

//Não consegui conectar ele na API,  
//nele eu fiz a parte referente a Funcionarios 
//só pra tentar testar mesmo, mas os outros seriam basicamente igual
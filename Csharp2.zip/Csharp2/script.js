function listarClientes() {
    // Realize uma solicitação HTTP (por exemplo, usando fetch) para obter a lista de usuários do seu backend.
    // Substitua a URL abaixo pela URL correta do seu backend.
    fetch('http://seu-backend.com/api/clientes')
        .then(response => response.json())
        .then(usuarios => {
            // Limpar a lista antes de preenchê-la novamente
            const listarClientes = document.getElementById('listarClientes');
            listarClientes.innerHTML = '';

            // Preencher lista com os usuários recebidos do backend
            for (const cliente of clientes) {
                const clienteItem = document.createElement('div');
                clienteItem.className = 'usuario-item';
                clienteItem.innerHTML = `
                    <strong>ID:</strong> ${cliente.id} <br>
                    <strong>Nome:</strong> ${cliente.nome} <br>
                    <strong>Email:</strong> ${cliente.email} <br>
                    <hr>
                `;
                listarClientes.appendChild(clienteItem);
            }
        })
        .catch(error => {
            console.error('Erro ao obter lista de usuários:', error);
        });
}

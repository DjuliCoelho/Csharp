﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MeuProjeto.Models; // Certifique-se de importar o namespace correto para as classes de modelo
using MeuProjeto.Data; // Certifique-se de que este seja o namespace correto


[Route("api/[controller]")]

[ApiController]
public class AnimalController : ControllerBase
{
    private readonly AnimalContext _context;

    public AnimalController(AnimalContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Animal>>> GetAnimais()

    {
        return await _context.Animais.ToListAsync();
    }

    [HttpPost]
public async Task<ActionResult<Animal>> PostAnimal(Animal Animal)
{
    // Adicione o objeto Animal ao contexto
    _context.Animais.Add(Animal);

    // Salve as alterações no banco de dados
    await _context.SaveChangesAsync();

    // Retorne uma resposta indicando que o recurso foi criado com sucesso
    // Você pode usar o método CreatedAtAction para criar uma resposta HTTP 201 (Created).
    return CreatedAtAction("GetAnimais", new { id = Animal.Id }, Animal);
}
}
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

public class Startup
{
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    public void ConfigureServices(IServiceCollection services)
    {
        // Configurações de banco de dados, serviços e injeção de dependência podem ser adicionados aqui.
        // Exemplo:
        // services.AddDbContext<MeuDbContext>(options =>
        //     options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

        // Configuração de outros serviços, se necessário.
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }
        else
        {
            app.UseExceptionHandler("/Home/Error");
            app.UseHsts();
        }

        // Configuração de autorização e autenticação, se necessário.

        // Configuração de middleware de resposta, como compressão, cache, etc.

        app.UseRouting();

        // Configuração de middleware específico da API, se necessário.

        app.UseEndpoints(endpoints =>
        {
            // Define endpoints de API personalizados aqui, se necessário.
            // endpoints.MapGet("/api/meuendpoint", async context =>
            // {
            //     await context.Response.WriteAsync("Hello API!");
            // });
        });
    }
}

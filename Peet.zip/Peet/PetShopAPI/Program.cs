using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.Sqlite;

class Program
{
    static void Main(string[] args)
    {
        var databasePath = "mydatabase.db"; // Nome do arquivo do banco de dados SQLite
        var sqliteManager = new SQLiteManager(databasePath);
        sqliteManager.CreateDatabase();// Cria o banco de dados se ele não existir
        while (true)
        {
            Console.WriteLine("Escolha uma entidade para gerenciar:");
            Console.WriteLine("1 - Funcionário");
            Console.WriteLine("2 - Cliente");
            Console.WriteLine("3 - Produto");
            Console.WriteLine("4 - Estoque");
            Console.WriteLine("5 - Sair");

            var escolhaEntidade = Console.ReadLine();

            switch (escolhaEntidade)
            {
                case "1":
                    GerenciarFuncionario(sqliteManager);// Chama a função para gerenciar funcionários
                    break;

                case "2":
                    GerenciarCliente(sqliteManager);// Chama a função para gerenciar clientes
                    break;

                case "3":
                    GerenciarProduto(sqliteManager);// Chama a função para gerenciar produtos
                    break;

                case "4":
                    GerenciarEstoque(sqliteManager);// Chama a função para gerenciar estoques
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }

    static void GerenciarFuncionario(SQLiteManager sqliteManager)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Funcionário:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoFuncionario = LerDadosFuncionario();// Lê os dados de um novo funcionário
                    sqliteManager.InserirFuncionario(novoFuncionario);// Insere o funcionário no banco de dados
                    break;

                case "2":
                    ListarFuncionarios(sqliteManager);
                    break;

                case "3":
                    Console.WriteLine("Digite o ID do Funcionário a ser atualizado:");
                    if (int.TryParse(Console.ReadLine(), out int idAtualizar))
                    {
                        var funcionarioAtualizado = LerDadosFuncionario();
                        sqliteManager.AtualizarFuncionario(idAtualizar, funcionarioAtualizado);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "4":
                    Console.WriteLine("Digite o ID do Funcionário a ser deletado:");
                    if (int.TryParse(Console.ReadLine(), out int idDeletar))
                    {
                        sqliteManager.DeletarFuncionario(idDeletar);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }

    static void GerenciarCliente(SQLiteManager sqliteManager)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Cliente:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoCliente = LerDadosCliente();
                    sqliteManager.InserirCliente(novoCliente);
                    break;

                case "2":
                    ListarClientes(sqliteManager);
                    break;

                case "3":
                    Console.WriteLine("Digite o ID do Cliente a ser atualizado:");
                    if (int.TryParse(Console.ReadLine(), out int idAtualizar))
                    {
                        var clienteAtualizado = LerDadosCliente();
                        sqliteManager.AtualizarCliente(idAtualizar, clienteAtualizado);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "4":
                    Console.WriteLine("Digite o ID do Cliente a ser deletado:");
                    if (int.TryParse(Console.ReadLine(), out int idDeletar))
                    {
                        sqliteManager.DeletarCliente(idDeletar);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }

    static void GerenciarProduto(SQLiteManager sqliteManager)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Produto:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoProduto = LerDadosProduto();
                    sqliteManager.InserirProduto(novoProduto);
                    break;

                case "2":
                    ListarProdutos(sqliteManager);
                    break;

                case "3":
                    Console.WriteLine("Digite o ID do Produto a ser atualizado:");
                    if (int.TryParse(Console.ReadLine(), out int idAtualizar))
                    {
                        var produtoAtualizado = LerDadosProduto();
                        sqliteManager.AtualizarProduto(idAtualizar, produtoAtualizado);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "4":
                    Console.WriteLine("Digite o ID do Produto a ser deletado:");
                    if (int.TryParse(Console.ReadLine(), out int idDeletar))
                    {
                        sqliteManager.DeletarProduto(idDeletar);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }

    static void GerenciarEstoque(SQLiteManager sqliteManager)
    {
        while (true)
        {
            Console.WriteLine("Escolha uma ação para Estoque:");
            Console.WriteLine("1 - Cadastrar");
            Console.WriteLine("2 - Listar todos");
            Console.WriteLine("3 - Atualizar");
            Console.WriteLine("4 - Deletar");
            Console.WriteLine("5 - Voltar");

            var escolhaAcao = Console.ReadLine();

            switch (escolhaAcao)
            {
                case "1":
                    var novoEstoque = LerDadosEstoque();
                    sqliteManager.InserirEstoque(novoEstoque);
                    break;

                case "2":
                    ListarEstoques(sqliteManager);
                    break;

                case "3":
                    Console.WriteLine("Digite o ID do Estoque a ser atualizado:");
                    if (int.TryParse(Console.ReadLine(), out int idAtualizar))
                    {
                        var estoqueAtualizado = LerDadosEstoque();
                        sqliteManager.AtualizarEstoque(idAtualizar, estoqueAtualizado);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "4":
                    Console.WriteLine("Digite o ID do Estoque a ser deletado:");
                    if (int.TryParse(Console.ReadLine(), out int idDeletar))
                    {
                        sqliteManager.DeletarEstoque(idDeletar);
                    }
                    else
                    {
                        Console.WriteLine("ID inválido. Tente novamente.");
                    }
                    break;

                case "5":
                    return;

                default:
                    Console.WriteLine("Escolha inválida. Tente novamente.");
                    break;
            }
        }
    }

    static Funcionario LerDadosFuncionario()
    {
        Console.WriteLine("Por favor, preencha os campos do Funcionário:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Cargo: ");
        var cargo = Console.ReadLine();

        var novoFuncionario = new Funcionario
        {
            Nome = nome,
            Cargo = cargo
        };

        return novoFuncionario;
    }

    static Cliente LerDadosCliente()
    {
        Console.WriteLine("Por favor, preencha os campos do Cliente:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Cpf: ");
        var cpf = Console.ReadLine();

        Console.Write("Fone: ");
        var fone = Console.ReadLine();

        var novoCliente = new Cliente
        {
            Nome = nome,
            Cpf = cpf,
            Fone = fone
        };

        return novoCliente;
    }

    static Produto LerDadosProduto()
    {
        Console.WriteLine("Por favor, preencha os campos do Produto:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Codigo: ");
        var codigo = Console.ReadLine();

        Console.Write("Valor: ");
        var valor = Console.ReadLine();

        var novoProduto = new Produto
        {
            Nome = nome,
            Codigo = codigo,
            Valor = valor
        };

        return novoProduto;
    }

    static Estoque LerDadosEstoque()
    {
        Console.WriteLine("Por favor, preencha os campos do Estoque:");
        Console.Write("Nome: ");
        var nome = Console.ReadLine();

        Console.Write("Quantidade: ");
        var Quantidade = Console.ReadLine();

        var novoEstoque = new Estoque
        {
            Nome = nome,
            Quantidade = Quantidade
        };

        return novoEstoque;
    }

    static void ListarFuncionarios(SQLiteManager sqliteManager)
    {
        var funcionarios = sqliteManager.ListarFuncionarios();

        Console.WriteLine("Lista de Funcionários:");
        foreach (var funcionario in funcionarios)
        {
            Console.WriteLine($"ID: {funcionario.Id}, Nome: {funcionario.Nome}, Cargo: {funcionario.Cargo}");
        }
    }

    static void ListarClientes(SQLiteManager sqliteManager)
    {
        var clientes = sqliteManager.ListarClientes();

        Console.WriteLine("Lista de Clientes:");
        foreach (var cliente in clientes)
        {
            Console.WriteLine($"Nome: {cliente.Nome}, Cpf: {cliente.Cpf}, Fone: {cliente.Fone}");
        }
    }

    static void ListarProdutos(SQLiteManager sqliteManager)
    {
        var produtos = sqliteManager.ListarProdutos();

        Console.WriteLine("Lista de Produtos:");
        foreach (var produto in produtos)
        {
            Console.WriteLine($"Nome: {produto.Nome}, Codigo: {produto.Codigo}, Valor: {produto.Valor}");
        }
    }

    static void ListarEstoques(SQLiteManager sqliteManager)
    {
        var estoques = sqliteManager.ListarEstoques();

        Console.WriteLine("Lista de Estoques:");
        foreach (var estoque in estoques)
        {
            Console.WriteLine($"Id: {estoque.Id}, Nome: {estoque.Nome}, Quantia: {estoque.Quantidade}");
        }
    }
}

// Definição das classes para representar os objetos no banco de dados
public class Funcionario
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Cargo { get; set; }
}

public class Cliente
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Cpf { get; set; }
    public string Fone { get; set; }
}

public class Produto
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Codigo { get; set; }
    public string Valor { get; set; }
}

public class Estoque
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Quantidade { get; set; }
}

// Classe para gerenciar o banco de dados SQLite
public class SQLiteManager
{
    private readonly string connectionString;

    public SQLiteManager(string databasePath)
    {
        connectionString = $"Data Source={databasePath}";
    }


// Função para criar o banco de dados e tabelas se não existirem
    public void CreateDatabase()
    {
        using (var connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                // Cria tabelas se não existirem
                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Funcionarios (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Nome TEXT,
                        Cargo TEXT
                    )";
                command.ExecuteNonQuery();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Clientes (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Nome TEXT,
                        Cpf TEXT,
                        Fone TEXT
                    )";
                command.ExecuteNonQuery();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Produtos (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Nome TEXT,
                        Codigo TEXT,
                        Valor TEXT
                    )";
                command.ExecuteNonQuery();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Estoques (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Nome TEXT,
                        Quantidade TEXT
                    )";
                command.ExecuteNonQuery();
            }
        }
    }

    public void InserirFuncionario(Funcionario funcionario)
    {
        using (var connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = "INSERT INTO Funcionarios (Nome, Cargo) VALUES (@Nome, @Cargo)";
                command.Parameters.AddWithValue("@Nome", funcionario.Nome);
                command.Parameters.AddWithValue("@Cargo", funcionario.Cargo);
                command.ExecuteNonQuery();
            }
        }
    }

    public List<Funcionario> ListarFuncionarios()
    {
        var funcionarios = new List<Funcionario>();

        using (var connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = "SELECT * FROM Funcionarios";

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        funcionarios.Add(new Funcionario
                        {
                            Id = reader.GetInt32(0),
                            Nome = reader.GetString(1),
                            Cargo = reader.GetString(2)
                        });
                    }
                }
            }
        }

        return funcionarios;
    }

    public void AtualizarFuncionario(int id, Funcionario funcionario)
    {
        using (var connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = "UPDATE Funcionarios SET Nome = @Nome, Cargo = @Cargo WHERE Id = @Id";
                command.Parameters.AddWithValue("@Nome", funcionario.Nome);
                command.Parameters.AddWithValue("@Cargo", funcionario.Cargo);
                command.Parameters.AddWithValue("@Id", id);
                command.ExecuteNonQuery();
            }
        }
    }

    public void DeletarFuncionario(int id)
    {
        using (var connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            using (var command = connection.CreateCommand())
            {
                command.CommandText = "DELETE FROM Funcionarios WHERE Id = @Id";
                command.Parameters.AddWithValue("@Id", id);
                command.ExecuteNonQuery();
            }
        }
    }

   public void InserirCliente(Cliente cliente)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "INSERT INTO Clientes (Nome, Cpf, Fone) VALUES (@Nome, @Cpf, @Fone)";
            command.Parameters.AddWithValue("@Nome", cliente.Nome);
            command.Parameters.AddWithValue("@Cpf", cliente.Cpf);
            command.Parameters.AddWithValue("@Fone", cliente.Fone);
            command.ExecuteNonQuery();
        }
    }
}

   // Funções para inserir, listar, atualizar e deletar funcionários, clientes, produtos e estoques

public List<Cliente> ListarClientes()
{
    var clientes = new List<Cliente>();

    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "SELECT * FROM Clientes";

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    clientes.Add(new Cliente
                    {
                        Id = reader.GetInt32(0),
                        Nome = reader.GetString(1),
                        Cpf = reader.GetString(2),
                        Fone = reader.GetString(3)
                    });
                }
            }
        }
    }

    return clientes;
}

public void AtualizarCliente(int id, Cliente cliente)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "UPDATE Clientes SET Nome = @Nome, Cpf = @Cpf, Fone = @Fone WHERE Id = @Id";
            command.Parameters.AddWithValue("@Nome", cliente.Nome);
            command.Parameters.AddWithValue("@Cpf", cliente.Cpf);
            command.Parameters.AddWithValue("@Fone", cliente.Fone);
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}

public void DeletarCliente(int id)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "DELETE FROM Clientes WHERE Id = @Id";
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}

public void InserirProduto(Produto produto)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "INSERT INTO Produtos (Nome, Codigo, Valor) VALUES (@Nome, @Codigo, @Valor)";
            command.Parameters.AddWithValue("@Nome", produto.Nome);
            command.Parameters.AddWithValue("@Codigo", produto.Codigo);
            command.Parameters.AddWithValue("@Valor", produto.Valor);
            command.ExecuteNonQuery();
        }
    }
}

public List<Produto> ListarProdutos()
{
    var produtos = new List<Produto>();

    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "SELECT * FROM Produtos";

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    produtos.Add(new Produto
                    {
                        Id = reader.GetInt32(0),
                        Nome = reader.GetString(1),
                        Codigo = reader.GetString(2),
                        Valor = reader.GetString(3)
                    });
                }
            }
        }
    }

    return produtos;
}

public void AtualizarProduto(int id, Produto produto)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "UPDATE Produtos SET Nome = @Nome, Codigo = @Codigo, Valor = @Valor WHERE Id = @Id";
            command.Parameters.AddWithValue("@Nome", produto.Nome);
            command.Parameters.AddWithValue("@Codigo", produto.Codigo);
            command.Parameters.AddWithValue("@Valor", produto.Valor);
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}

public void DeletarProduto(int id)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "DELETE FROM Produtos WHERE Id = @Id";
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}

public void InserirEstoque(Estoque estoque)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "INSERT INTO Estoques (Nome, Quantidade) VALUES (@Nome, @Quantidade)";
            command.Parameters.AddWithValue("@Nome", estoque.Nome);
            command.Parameters.AddWithValue("@Quantidade", estoque.Quantidade);
            command.ExecuteNonQuery();
        }
    }
}

public List<Estoque> ListarEstoques()
{
    var estoques = new List<Estoque>();

    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "SELECT * FROM Estoques";

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    estoques.Add(new Estoque
                    {
                        Id = reader.GetInt32(0),
                        Nome = reader.GetString(1),
                        Quantidade = reader.GetString(2)
                    });
                }
            }
        }
    }

    return estoques;
}

public void AtualizarEstoque(int id, Estoque estoque)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "UPDATE Estoques SET Nome = @Nome, Quantidade = @Quantidade WHERE Id = @Id";
            command.Parameters.AddWithValue("@Nome", estoque.Nome);
            command.Parameters.AddWithValue("@Quantidade", estoque.Quantidade);
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}

public void DeletarEstoque(int id)
{
    using (var connection = new SqliteConnection(connectionString))
    {
        connection.Open();

        using (var command = connection.CreateCommand())
        {
            command.CommandText = "DELETE FROM Estoques WHERE Id = @Id";
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}
}
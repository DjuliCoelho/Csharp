using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace ArqSoft.Controllers
{
    [ApiController]
    [Route("api/registroanimal")]
    public class RegistroAnimalController : ControllerBase
    {
        private readonly PetshopDbContext _context;

        public RegistroAnimalController(PetshopDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult RegistrarAnimal([FromBody] Pet animal)
        {
            if (animal == null)
            {
                return BadRequest("Dados do animal inválidos");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest("Dados do animal inválidos");
            }

            if (DataNascimentoFutura(animal.DataNascimento))
            {
                return BadRequest("A data de nascimento não pode estar no futuro.");
            }

            try
            {
                _context.Pets.Add(animal);
                _context.SaveChanges();
                return Ok("Animal registrado com sucesso!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro ao registrar o animal: {ex.Message}");
            }
        }

        [HttpGet]
        public IActionResult ObterAnimais()
        {
            var animais = _context.Pets.ToList();
            return Ok(animais);
        }

        [HttpGet("{id}")]
        public IActionResult ObterAnimalPorId(int id)
        {
            var animal = _context.Pets.Find(id);
            if (animal == null)
            {
                return NotFound("Animal não encontrado");
            }

            return Ok(animal);
        }

        [HttpPut("{id}")]
        public IActionResult AtualizarAnimal(int id, [FromBody] Pet animalAtualizado)
        {
            var animal = _context.Pets.Find(id);
            if (animal == null)
            {
                return NotFound("Animal não encontrado");
            }

            // Atualizar os campos do animal com base nos dados fornecidos
            animal.Nome = animalAtualizado.Nome;
            animal.Especie = animalAtualizado.Especie;
            // Adicione outras atualizações necessárias

            _context.SaveChanges();
            return Ok("Animal atualizado com sucesso!");
        }

        [HttpDelete("{id}")]
        public IActionResult DeletarAnimal(int id)
        {
            var animal = _context.Pets.Find(id);
            if (animal == null)
            {
                return NotFound("Animal não encontrado");
            }

            _context.Pets.Remove(animal);
            _context.SaveChanges();
            return Ok("Animal removido com sucesso!");
        }

        private bool DataNascimentoFutura(DateTime dataNascimento)
        {
            return dataNascimento > DateTime.Now;
        }
    }
}

using Microsoft.EntityFrameworkCore;

public class PetshopDbContext : DbContext
{
    public PetshopDbContext(DbContextOptions<PetshopDbContext> options) : base(options) { }

    public DbSet<Pet> Pets { get; set; }
}
